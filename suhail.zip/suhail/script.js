const loginForm = document.getElementById('loginForm');
const doctorSection = document.getElementById('doctorSection');
const pharmacySection = document.getElementById('pharmacySection');
const diagnosticSection = document.getElementById('diagnosticSection');
const patientSection = document.getElementById('patientSection');
const patientRecordsDiv = document.getElementById('patientRecords');
const medicineDropdown = document.getElementById('medicineDropdown');
const pharmacyInventoryDiv = document.getElementById('pharmacyInventory');

let patients = [];
let pharmacyInventory = [];

// Function to show specific user dashboard based on role
loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const role = document.getElementById('role').value;

    hideAllSections();

    switch (role) {
        case 'doctor':
            doctorSection.classList.remove('hidden');
            populateMedicineDropdown();
            break;
        case 'pharmacy':
            pharmacySection.classList.remove('hidden');
            displayPharmacyInventory();
            break;
        case 'diagnostic_center':
            diagnosticSection.classList.remove('hidden');
            break;
        case 'patient':
            patientSection.classList.remove('hidden');
            displayPatientHistory();
            break;
    }
});

// Function to hide all sections
function hideAllSections() {
    doctorSection.classList.add('hidden');
    pharmacySection.classList.add('hidden');
    diagnosticSection.classList.add('hidden');
    patientSection.classList.add('hidden');
}

// Pharmacy Section - Add medicine to inventory
const medicineForm = document.getElementById('medicineForm');
medicineForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const medicineName = document.getElementById('medicineName').value;
    const medicineQty = document.getElementById('medicineQty').value;

    pharmacyInventory.push({ name: medicineName, quantity: parseInt(medicineQty) });
    displayPharmacyInventory();
});

// Function to display pharmacy inventory
function displayPharmacyInventory() {
    pharmacyInventoryDiv.innerHTML = '';
    pharmacyInventory.forEach((medicine, index) => {
        pharmacyInventoryDiv.innerHTML += `<p>${medicine.name}: ${medicine.quantity} units available</p>`;
    });
}

// Function to populate medicine dropdown in doctor's section
function populateMedicineDropdown() {
    medicineDropdown.innerHTML = '';
    pharmacyInventory.forEach((medicine) => {
        if (medicine.quantity > 0) {
            const option = document.createElement('option');
            option.value = medicine.name;
            option.textContent = `${medicine.name} (Available: ${medicine.quantity})`;
            medicineDropdown.appendChild(option);
        }
    });
}

// Doctor Section - Add patient and prescription
const patientForm = document.getElementById('patientForm');
patientForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const gender = document.getElementById('gender').value;
    const history = document.getElementById('history').value;
    const selectedMedicine = document.getElementById('medicineDropdown').value;
    const prescription = document.getElementById('prescription').value;

    // Reduce inventory of the prescribed medicine
    pharmacyInventory = pharmacyInventory.map((medicine) => {
        if (medicine.name === selectedMedicine) {
            medicine.quantity -= 1;
        }
        return medicine;
    });

    // Save patient data
    const patientData = {
        name,
        age,
        gender,
        history,
        prescription: `${prescription}\nMedicine: ${selectedMedicine}`
    };

    patients.push(patientData);
    displayPatients();
    populateMedicineDropdown();
});

// Function to display patients
function displayPatients() {
    patientRecordsDiv.innerHTML = '';
    patients.forEach((patient, index) => {
        const patientCard = document.createElement('div');
        patientCard.classList.add('patient-card');

        patientCard.innerHTML = `
           
